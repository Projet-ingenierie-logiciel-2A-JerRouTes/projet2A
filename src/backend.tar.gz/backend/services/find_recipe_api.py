from __future__ import annotations

import logging
from typing import Protocol

from business_objects.recipe import Recipe
from business_objects.user import GenericUser
from clients.spoonacular_client import (
    SpoonacularRateLimitError,
    fetch_detailed_recipes_by_ingredients,
)
from services.find_recipe import FindRecipe, IngredientSearchQuery
from business_objects.unit import Unit
from dao.ingredient_dao import IngredientDAO

class RecipeWriteDao(Protocol):
    """Sous-ensemble du DAO nécessaire pour 'cacher' les recettes externes en BDD."""

    def list_recipes(
        self,
        *,
        fk_user_id: int | None = None,
        name_ilike: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Recipe]: ...

    def create_recipe(
        self,
        *,
        fk_user_id: int | None,
        name: str,
        status: str | None = "draft",
        prep_time: int | None = 0,
        portion: int | None = 1,
        description: str | None = None,
        ingredient_items=None,
        tag_ids=None,
    ) -> Recipe: ...


class ApiFindRecipe(FindRecipe):
    def __init__(
        self,
        api_key: str,
        *,
        dao: RecipeWriteDao | None = None,
        ingredient_dao: IngredientDAO | None = None,
    ):
        self._api_key = api_key
        self._dao = dao
        self._ingredient_dao = ingredient_dao

    def get_by_id(self, _recipe_id: int) -> Recipe | None:
        """Lookup par id."""
        return None

    def search_by_ingredients(self, query: IngredientSearchQuery) -> list[Recipe]:
        ingredients = [s.strip() for s in query.ingredients if s and s.strip()]
        if not ingredients:
            return []

        try:
            detailed = fetch_detailed_recipes_by_ingredients(
                api_key=self._api_key,
                ingredients=ingredients,
                n=query.limit,
                dish_type=query.dish_type,
                strict_only=query.strict_only,
                max_missing_ingredients=query.max_missing,
                sort="min-missing-ingredients"
                if query.max_missing > 0
                else "max-used-ingredients",
                ignore_pantry=query.ignore_pantry,
                instructions_required=True,
            )
        except SpoonacularRateLimitError as e:
            logging.getLogger(__name__).warning(
                "Spoonacular quota exceeded - returning empty results: %s", e
            )
            return []

        if self._dao is None:
            return [self._detailed_to_bo(r) for r in detailed]

        saved: list[Recipe] = []
        for r in detailed:
            saved.append(self._get_or_create_local_recipe(r))
        return saved

    @staticmethod
    def _detailed_to_bo(r) -> Recipe:
        creator = GenericUser(id_user=0, pseudo="external", password="____")

        recipe = Recipe(
            recipe_id=int(r.id),
            creator=creator,
            status="public",
            prep_time=int(r.ready_in_minutes or 0),
            portions=int(r.servings or 1),
        )
        recipe.add_translation("en", r.title, "")

        recipe.steps = [
            st.step for st in sorted((r.steps or []), key=lambda s: s.number)
        ]

        if r.steps:
            text = "\n".join(f"{st.number}. {st.step}" for st in r.steps)
            recipe.add_translation("en_steps", r.title, text)

        return recipe

    def _get_or_create_local_recipe(self, r) -> Recipe:
        assert self._dao is not None

        title = (r.title or "").strip()

        if title:
            candidates = self._dao.list_recipes(name_ilike=title, limit=10, offset=0)
            for c in candidates:
                fr_name = (c.translations.get("fr") or {}).get("name", "")
                if fr_name.strip().lower() == title.lower():
                    return c

        description_parts: list[str] = []
        if getattr(r, "source_url", None):
            description_parts.append(f"Source: {r.source_url}")
        if getattr(r, "summary", None):
            description_parts.append(str(r.summary))
        if getattr(r, "steps", None):
            steps_txt = "\n".join(
                f"{st.number}. {st.step}"
                for st in sorted(r.steps, key=lambda s: s.number)
            )
            if steps_txt.strip():
                description_parts.append("\nPréparation:\n" + steps_txt)

        description = (
            "\n\n".join(p for p in description_parts if p and str(p).strip()) or None
        )

        ingredient_items = []
        if self._ingredient_dao is not None:
            for ing in (getattr(r, "ingredients", None) or []):
                ing_name = (getattr(ing, "name", None) or "").strip()
                ing_unit = (getattr(ing, "unit", None) or None)
                ing_amount = float(getattr(ing, "amount", 0.0) or 0.0)

                if not ing_name:
                    continue

                ing_id = self._get_or_create_ingredient_id(ing_name, ing_unit)
                ingredient_items.append((ing_id, ing_amount))

        created = self._dao.create_recipe(
            fk_user_id=None,
            name=title or "(Sans titre)",
            status="public",
            prep_time=int(getattr(r, "ready_in_minutes", 0) or 0),
            portion=int(getattr(r, "servings", 1) or 1),
            description=description,
            ingredient_items=ingredient_items or None,
        )

        created.steps = [
            st.step
            for st in sorted((getattr(r, "steps", None) or []), key=lambda s: s.number)
        ]
        created.add_translation("en", title, description or "")
        return created

    def _get_or_create_ingredient_id(self, name: str, unit_raw: str | None) -> int:
        assert self._ingredient_dao is not None

        clean_name = (name or "").strip()
        if not clean_name:
            raise ValueError("Ingredient name is empty")

        existing = self._ingredient_dao.get_ingredient_by_name(clean_name)
        if existing:
            return int(existing.id_ingredient)

        # unit_raw vient de Spoonacular (ex: "g", "tbsp", "cup"...)
        # Unit.from_any gère beaucoup de cas, sinon on met None -> default côté DAO
        unit_value = None
        if unit_raw:
            try:
                unit_value = Unit.from_any(unit_raw)
            except Exception:
                unit_value = None

        created = self._ingredient_dao.create_ingredient(name=clean_name, unit=unit_value)
        return int(created.id_ingredient)